/* THREAD - site scripts: nav, products, search/filter/sort, cart, accordion, tabs, lightbox, modal, forms, map */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fmt = n => "R" + (Math.round(n * 100) / 100);
  const IMG = "images/";
  const EMAIL = "info@threadstore.com";
  const FORM_ENDPOINT = ""; // optional: paste a Formspree URL here to send the contact form with AJAX
  function el(tag, attrs, kids) {
    const e = document.createElement(tag);
    for (const k in (attrs || {})) { k === "text" ? (e.textContent = attrs[k]) : e.setAttribute(k, attrs[k]); }
    (kids || []).forEach(c => e.append(c));
    return e;
  }
  function toast(msg) {
    const t = el("div", { class: "toast", role: "status", text: msg });
    document.body.append(t); setTimeout(() => t.remove(), 2200);
  }

  /* Mobile nav */
  const toggle = $(".nav-toggle"), nav = $("#main-nav");
  if (toggle) toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open"); toggle.setAttribute("aria-expanded", open);
  });

  /* Cart (stored in localStorage; only id + qty saved, prices always read from products.js) */
  const KEY = "threadCart";
  const getCart = () => { try { return JSON.parse(localStorage.getItem(KEY)) || []; } catch (e) { return []; } };
  const saveCart = c => { try { localStorage.setItem(KEY, JSON.stringify(c)); } catch (e) {} badge(); };
  function badge() { const n = getCart().reduce((s, i) => s + i.qty, 0); $$(".cart-count").forEach(b => b.textContent = n); }
  function addToCart(id) {
    const p = PRODUCTS.find(x => x.id === id); if (!p) return;
    const c = getCart(), f = c.find(i => i.id === id);
    f ? f.qty++ : c.push({ id, qty: 1 }); saveCart(c); toast(p.name + " added to cart");
  }
  badge();

  /* Product cards, built dynamically from products.js */
  function card(p, delay) {
    const img = el("img", { src: IMG + p.image, alt: p.name + " - " + p.gender + " from the THREAD collection", loading: "lazy" });
    img.addEventListener("click", () => openLightbox([p], 0));
    const btn = el("button", { class: "add-cart", "data-name": p.name, "data-price": p.price, text: "Add to Cart" });
    btn.addEventListener("click", () => addToCart(p.id));
    const a = el("article", { class: "product card", "data-gender": p.gender, "data-category": p.category, "data-price": p.price, style: "animation-delay:" + delay + "ms" },
      [img, el("h3", { text: p.name }), el("p", { text: p.gender }), el("p", { text: "Category: " + p.category }), el("p", { class: "price", text: fmt(p.price) }), btn]);
    return a;
  }
  const featured = $("#featured-products");
  if (featured) PRODUCTS.slice(0, 4).forEach((p, i) => featured.append(card(p, i * 90)));

  /* Shop: search, filter and sort */
  const grid = $("#products");
  if (grid) {
    const q = $("#search"), g = $("#filter-gender"), c = $("#filter-category"), s = $("#sort"), count = $("#result-count");
    [...new Set(PRODUCTS.map(p => p.category))].sort().forEach(x => c.append(el("option", { value: x, text: x })));
    const render = () => {
      const term = q.value.trim().toLowerCase();
      let list = PRODUCTS.filter(p => (!term || (p.name + " " + p.category + " " + p.gender).toLowerCase().includes(term)) &&
        (!g.value || p.gender.startsWith(g.value)) && (!c.value || p.category === c.value));
      if (s.value === "low") list.sort((a, b) => a.price - b.price);
      if (s.value === "high") list.sort((a, b) => b.price - a.price);
      if (s.value === "name") list.sort((a, b) => a.name.localeCompare(b.name));
      grid.replaceChildren(...list.map((p, i) => card(p, i * 60)));
      count.textContent = list.length ? list.length + " product(s) found" : "No products match your search. Try clearing the filters.";
    };
    [q, g, c, s].forEach(x => x.addEventListener("input", render)); render();
  }

  /* Accordion */
  $$(".accordion-btn").forEach(b => b.addEventListener("click", () => {
    const panel = document.getElementById(b.getAttribute("aria-controls")), open = b.getAttribute("aria-expanded") === "true";
    b.setAttribute("aria-expanded", !open); panel.hidden = open;
  }));

  /* Tabs */
  $$(".tab").forEach(t => t.addEventListener("click", () => {
    $$(".tab").forEach(x => x.setAttribute("aria-selected", x === t));
    $$(".tabpanel").forEach(p => p.hidden = p.id !== t.getAttribute("aria-controls"));
  }));

  /* Overlays: lightbox + checkout modal */
  let lastFocus = null;
  function openOverlay(o) { lastFocus = document.activeElement; o.classList.add("open"); const f = $("button", o); if (f) f.focus(); }
  function closeOverlay(o) { o.classList.remove("open"); if (lastFocus) lastFocus.focus(); }
  document.addEventListener("keydown", e => {
    const o = $(".overlay.open"); if (!o) return;
    if (e.key === "Escape") closeOverlay(o);
    if (o.id === "lightbox") { if (e.key === "ArrowRight") step(1); if (e.key === "ArrowLeft") step(-1); }
  });
  $$(".overlay").forEach(o => o.addEventListener("click", e => { if (e.target === o) closeOverlay(o); }));
  const lb = $("#lightbox"); let lbList = [], lbIdx = 0;
  function showLb() { const p = lbList[lbIdx]; $("#lb-img").src = IMG + p.image; $("#lb-img").alt = p.name; $("#lb-cap").textContent = p.name + " - " + fmt(p.price); }
  function openLightbox(list, i) { if (!lb) return; lbList = list; lbIdx = i; showLb(); $$(".lb-prev,.lb-next").forEach(b => b.style.display = list.length > 1 ? "" : "none"); openOverlay(lb); }
  function step(d) { lbIdx = (lbIdx + d + lbList.length) % lbList.length; showLb(); }
  if (lb) {
    $(".lb-close").addEventListener("click", () => closeOverlay(lb));
    $(".lb-prev").addEventListener("click", () => step(-1)); $(".lb-next").addEventListener("click", () => step(1));
    const gal = $("#gallery");
    if (gal) PRODUCTS.forEach((p, i) => {
      const b = el("button", { type: "button", "aria-label": "View " + p.name + " larger" }, [el("img", { src: IMG + p.image, alt: p.name + " - " + p.gender, loading: "lazy" })]);
      b.addEventListener("click", () => openLightbox(PRODUCTS, i)); gal.append(b);
    });
  }

  /* Cart page */
  const list = $("#cartItems");
  if (list) {
    const modal = $("#checkoutModal");
    const draw = () => {
      const cart = getCart().filter(i => PRODUCTS.some(p => p.id === i.id)); let total = 0;
      list.replaceChildren();
      if (!cart.length) list.append(el("li", { text: "Your cart is empty." }));
      cart.forEach(i => {
        const p = PRODUCTS.find(x => x.id === i.id); total += p.price * i.qty;
        const minus = el("button", { "aria-label": "Decrease quantity of " + p.name, text: "−" }), plus = el("button", { "aria-label": "Increase quantity of " + p.name, text: "+" });
        const rm = el("button", { class: "btn", style: "margin:0", text: "Remove" });
        minus.addEventListener("click", () => { i.qty--; saveCart(getCart().map(x => x.id === i.id ? i : x).filter(x => x.qty > 0)); draw(); });
        plus.addEventListener("click", () => { i.qty++; saveCart(getCart().map(x => x.id === i.id ? i : x)); draw(); });
        rm.addEventListener("click", () => { saveCart(getCart().filter(x => x.id !== i.id)); draw(); });
        list.append(el("li", {}, [el("span", { text: p.name + " (" + fmt(p.price) + ")" }), el("span", { class: "qty" }, [minus, el("span", { text: " " + i.qty + " " }), plus]), el("strong", { text: fmt(p.price * i.qty) }), rm]));
      });
      $("#cartTotal").textContent = total.toString();
    };
    draw();
    $("#clearCart").addEventListener("click", () => { saveCart([]); draw(); });
    $("#checkout").addEventListener("click", () => {
      const cart = getCart(); if (!cart.length) return toast("Your cart is empty.");
      const total = cart.reduce((s, i) => s + PRODUCTS.find(p => p.id === i.id).price * i.qty, 0);
      const delivery = total >= 1000 ? 0 : 80;
      $("#orderSummary").textContent = cart.reduce((s, i) => s + i.qty, 0) + " item(s). Subtotal " + fmt(total) + ", delivery " + (delivery ? fmt(delivery) : "FREE") + ". Total " + fmt(total + delivery) + ".";
      $("#confirmOrder").style.display = ""; $("#orderDone").textContent = "";
      openOverlay(modal);
    });
    $("#confirmOrder").addEventListener("click", e => {
      saveCart([]); draw(); $("#orderSummary").textContent = "";
      $("#orderDone").textContent = "Thank you! Your order has been placed (demo checkout - no payment taken).";
      e.target.style.display = "none";
    });
    $("#closeModal").addEventListener("click", () => closeOverlay(modal));
  }

  /* Form validation */
  const rules = {
    name: v => /^[A-Za-z][A-Za-z '\-]+$/.test(v) ? "" : "Use letters, spaces, hyphens or apostrophes only.",
    email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? "" : "Enter a valid email address, e.g. name@example.com.",
    phone: v => /^(\+27|0)[1-9]\d{8}$/.test(v.replace(/[\s-]/g, "")) ? "" : "Enter a valid South African number, e.g. 012 345 6789.",
    qty: v => /^\d+$/.test(v) && +v >= 1 && +v <= 100 ? "" : "Enter a whole number between 1 and 100.",
    date: v => { const d = new Date(v), t = new Date(); t.setHours(0, 0, 0, 0); const m = new Date(t); m.setFullYear(t.getFullYear() + 1);
      return d >= t && d <= m ? "" : "Choose a date from today up to one year ahead."; }
  };
  function check(f) {
    const v = f.value.trim();
    if (f.required && !v) return "This field is required.";
    if (!v) return "";
    if (f.minLength > 0 && v.length < f.minLength) return "Please enter at least " + f.minLength + " characters.";
    if (f.maxLength > 0 && v.length > f.maxLength) return "Please use no more than " + f.maxLength + " characters.";
    return f.dataset.rule ? rules[f.dataset.rule](v) : "";
  }
  function setErr(f, msg) { const e = document.getElementById(f.id + "-error"); if (e) e.textContent = msg; f.classList.toggle("invalid", !!msg); f.setAttribute("aria-invalid", !!msg); }
  function validate(form) {
    let ok = true, first = null;
    $$("input, select, textarea", form).forEach(f => { const m = check(f); setErr(f, m); if (m) { ok = false; first = first || f; } });
    if (first) first.focus(); return ok;
  }
  $$("form[data-validate]").forEach(form => $$("input, select, textarea", form).forEach(f => f.addEventListener("blur", () => setErr(f, check(f)))));

  /* Contact form: compile an email and send (AJAX if an endpoint is set, otherwise opens the visitor's email app) */
  const cf = $("#contactForm");
  if (cf) cf.addEventListener("submit", async e => {
    e.preventDefault(); if (!validate(cf)) return;
    const d = Object.fromEntries(new FormData(cf)), out = $("#formStatus");
    const subject = "[" + d.msgType + "] Message from " + d.name;
    const body = "Name: " + d.name + "\nEmail: " + d.email + "\nPhone: " + (d.phone || "not given") + "\nType: " + d.msgType + "\n\n" + d.message;
    if (FORM_ENDPOINT) {
      try {
        const r = await fetch(FORM_ENDPOINT, { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify(d) });
        if (!r.ok) throw new Error(); out.textContent = "Thank you " + d.name + "! Your message has been sent."; cf.reset(); return;
      } catch (err) { out.textContent = "Sending failed - we'll open your email app instead."; }
    }
    const link = "mailto:" + EMAIL + "?subject=" + encodeURIComponent(subject) + "&body=" + encodeURIComponent(body);
    out.replaceChildren("Your email to " + EMAIL + " is ready. If your email app did not open, ", el("a", { href: link, text: "click here to send it" }), ".");
    window.location.href = link;
  });

  /* Enquiry form: validates, then shows a quote / availability response */
  const ef = $("#enquiryForm");
  if (ef) {
    const sel = $("#product"); PRODUCTS.forEach(p => sel.append(el("option", { value: p.id, text: p.name + " - " + fmt(p.price) })));
    const typeSel = $("#enquiryType"), prodFields = $$(".product-field");
    typeSel.addEventListener("change", () => { const prod = typeSel.value === "Product price and availability" || typeSel.value === "Bulk or team order";
      prodFields.forEach(x => x.hidden = !prod); $$("select, input", $("#productFields")).forEach(f => { f.required = prod; if (!prod) setErr(f, ""); }); });
    ef.addEventListener("submit", e => {
      e.preventDefault(); if (!validate(ef)) return;
      const d = Object.fromEntries(new FormData(ef)), out = $("#enquiryResult"); out.replaceChildren();
      if (d.enquiryType === "Become a stockist or sponsor") { out.textContent = "Thanks " + d.name + "! Our partnerships team will contact you on " + d.phone + " within 3 working days."; return; }
      const p = PRODUCTS.find(x => x.id === +d.product), qty = +d.quantity;
      const stock = 5 + (p.id * 7) % 20, rate = qty >= 25 ? 0.15 : qty >= 10 ? 0.10 : 0;
      const sub = p.price * qty * (1 - rate), del = sub >= 1000 ? 0 : 80;
      const rows = [["Product", p.name + " (size " + d.size + ")"], ["Unit price", fmt(p.price)], ["Quantity", qty],
        ["Discount", rate ? rate * 100 + "% bulk discount" : "None"], ["Delivery", del ? fmt(del) : "FREE"], ["Estimated total", fmt(sub + del)],
        ["Availability", qty <= stock ? "In stock - ships in 3 to 5 working days" : "Only " + stock + " in stock - the rest is ready in about 7 working days"],
        ["Needed by", d.needBy]];
      const dl = el("dl", { class: "quote" }); rows.forEach(r => dl.append(el("dt", { text: r[0] }), el("dd", { text: String(r[1]) })));
      out.append(el("p", { text: "Thank you " + d.name + ", here is your quote:" }), dl, el("p", { text: "A confirmation will be sent to " + d.email + "." }));
    });
  }

  /* Interactive map (Leaflet + OpenStreetMap) */
  const mapDiv = $("#map");
  if (mapDiv) {
    if (window.L) {
      const m = L.map("map").setView([-26.2041, 28.0473], 13);
      L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: "&copy; OpenStreetMap contributors" }).addTo(m);
      L.marker([-26.2041, 28.0473]).addTo(m).bindPopup("<strong>THREAD</strong><br>Style That Speaks For You").openPopup();
    } else mapDiv.textContent = "Map could not be loaded. THREAD is based in Johannesburg, South Africa.";
  }
})();