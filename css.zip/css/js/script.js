/* THREAD product data - one place to add/edit products. Images are in /images (original file names kept). */
const PRODUCTS = [
  { id:1,  name:"THREAD Distressed Basil Tee", gender:"Men's Clothing",   category:"Tops",      price:550, image:"men's top.jpeg" },
  { id:2,  name:"THREAD Denim Cropped Zip Top", gender:"Women's Clothing", category:"Tops",      price:300, image:"women's top.jpeg" },
  { id:3,  name:"THREAD Distressed Jersey",     gender:"Men's Clothing",   category:"Outerwear",       price:650, image:"men's top 2.jpeg" },
  { id:4,  name:"THREAD x Adidas Corset Runway Piece",          gender:"Women's Clothing", category:"Tops",      price:1950, image:"women's top 2.jpeg" },
  { id:5,  name:"THREAD Blast Baggy Hoodie",    gender:"Men's Clothing",   category:"Outerwear",     price:950, image:"men's jacket 2.jpeg" },
  { id:6,  name:"THREAD Faded Yellow Zip-up",  gender:"Women's Clothing", category:"Outerwear",     price:900, image:"woman's jacket 2.jpeg" },
  { id:7,  name:"THREAD Leather Runway Piece",         gender:"Men's Clothing",   category:"Outerwear",     price:600, image:"men's jacket 3.jpeg" },
  { id:8,  name:"THREAD x Chrome Hearts Tank Tee",    gender:"Women's Clothing", category:"Tops",      price:550, image:"woman's top3.jpeg" },
  { id:9,  name:"THREAD Denim Barrel Jeans",       gender:"Unisex Clothing",  category:"Bottoms",     price:500, image:"unisex bottoms.jpeg" },
  { id:10, name:"THREAD Light Denim Jeans",    gender:"Women's Clothing",  category:"Bottoms",        price:320, image:"unisex bottoms 2.jpeg" },
  { id:11, name:"THREAD Baggy Grey Jeans",   gender:"Unisex",           category:"Bottoms", price:450, image:"unisex bottoms 3.jpeg" }
];